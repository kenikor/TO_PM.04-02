﻿using System;
using System.Collections.Generic;

namespace AutoPartsStore.Models;

public partial class Ordersummary
{
    public int OrderId { get; set; }

    public string Username { get; set; } = null!;

    public DateTime OrderDate { get; set; }

    public decimal? TotalAmount { get; set; }
}
