﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace AutoPartsStore.Models;

public partial class User
{
    public int UserId { get; set; }

    public string Username { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public string? FullName { get; set; }

    public string? Email { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    public ObservableCollection<CartItem> Cart { get; set; }
}
