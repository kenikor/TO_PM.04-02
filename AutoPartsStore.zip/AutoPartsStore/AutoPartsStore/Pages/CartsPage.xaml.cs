﻿using AutoPartsStore.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoPartsStore.Pages
{
    /// <summary>
    /// Логика взаимодействия для CartsPage.xaml
    /// </summary>
    public partial class CartsPage : Page, INotifyPropertyChanged
    {
        private Frame _frame;
        private User _user;

        public ObservableCollection<CartItem> CartItems { get; set; }

        public decimal TotalSum => CartItems.Sum(x => x.TotalPrice);

        public CartsPage(Frame frame, User user)
        {
            InitializeComponent();
            _frame = frame;
            _user = user;

            CartItems = _user?.Cart ?? new ObservableCollection<CartItem>();

            CartItems.CollectionChanged += (s, e) =>
            {
                OnPropertyChanged(nameof(TotalSum));
            };

            foreach (var item in CartItems)
            {
                item.PropertyChanged += Item_PropertyChanged;
            }

            DataContext = this;
        }

        private void Item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Quantity")
            {
                OnPropertyChanged(nameof(TotalSum));
            }
        }

        private void RemoveFromCart_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is CartItem item)
            {
                item.Product.Stock += item.Quantity;
                CartItems.Remove(item);
                OnPropertyChanged(nameof(TotalSum));
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.GoBack();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private void Checkout_Click(object sender, RoutedEventArgs e)
        {
            if (_user == null)
            {
                MessageBox.Show("Нужно войти в систему");
                return;
            }

            if (CartItems == null || !CartItems.Any())
            {
                MessageBox.Show("Корзина пустая");
                return;
            }

            try
            {
                using (var db = new StoreContext())
                {
                    var order = new Order
                    {
                        UserId = _user.UserId,
                        OrderDate = DateTime.Now
                    };

                    db.Orders.Add(order);
                    db.SaveChanges(); 

                    foreach (var item in CartItems)
                    {
                        var orderItem = new Orderitem
                        {
                            OrderId = order.OrderId,
                            ProductId = item.Product.ProductId,
                            Quantity = item.Quantity
                        };

                        db.Orderitems.Add(orderItem);
                    }

                    db.SaveChanges();
                }

                CartItems.Clear();
                OnPropertyChanged(nameof(TotalSum));

                MessageBox.Show("Заказ успешно оформлен 🚀");

                _frame.Navigate(new OrdersPage(_frame, _user));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при оформлении заказа: {ex.Message}");
            }
        }
    }
}
