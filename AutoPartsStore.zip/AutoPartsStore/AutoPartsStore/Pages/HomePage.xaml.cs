﻿using AutoPartsStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoPartsStore.Pages
{
    /// <summary>
    /// Логика взаимодействия для HomePage.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        private Frame _frame;
        private User _user;
        public HomePage(Frame frame, User user = null)
        {
            InitializeComponent();
            _frame = frame;
            _user = user;

            UpdateUI();
        }
        private void UpdateUI()
        {
            if (_user != null)
            {
                UserBlock.Visibility = Visibility.Visible;
                UserNameText.Text = _user.FullName;

                LoginButtons.Visibility = Visibility.Collapsed;
                LogoutButton.Visibility = Visibility.Visible;
                OrdersButton.Visibility = Visibility.Visible;
            }
            else
            {
                UserBlock.Visibility = Visibility.Collapsed;

                LoginButtons.Visibility = Visibility.Visible;
                LogoutButton.Visibility = Visibility.Collapsed;
                OrdersButton.Visibility = Visibility.Collapsed;
            }
        }

        private void GoToLogin_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new LoginPage(_frame));
        }

        private void GoToRegister_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new RegisterPage(_frame));
        }

        private void GoToCatalog_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new ProductsPage(_frame, _user));
        }

        private void GoToOrders_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new OrdersPage(_frame, _user));
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            _user = null;
            MessageBox.Show("Вы вышли из аккаунта");
            UpdateUI();
        }
    }
}
