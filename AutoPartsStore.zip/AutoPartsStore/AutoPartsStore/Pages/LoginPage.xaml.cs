﻿using AutoPartsStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;

namespace AutoPartsStore.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        private Frame _frame;

        public LoginPage(Frame frame)
        {
            InitializeComponent();
            _frame = frame;
        }
        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            ErrorText.Text = "";

            string email = EmailBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password))
            {
                ErrorText.Text = "Введите email и пароль";
                return;
            }

            try
            {
                var user = await AuthenticateUser(email, password);

                if (user == null)
                {
                    ErrorText.Text = "Неверный email или пароль";
                    return;
                }

                _frame.Navigate(new ProductsPage(_frame, user));
            }
            catch (Exception)
            {
                ErrorText.Text = "Ошибка входа";
            }
        }

        private async Task<User> AuthenticateUser(string email, string password)
        {
            return await Task.Run(() =>
            {
                using (var db = new StoreContext())
                {
                    var user = db.Users.FirstOrDefault(u => u.Email == email);

                    if (user == null)
                        return null;

                    bool isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);

                    return isValid ? user : null;
                }
            });
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new HomePage(_frame)); 
        }

        private void GoToRegister_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new RegisterPage(_frame));
        }
    }
}
