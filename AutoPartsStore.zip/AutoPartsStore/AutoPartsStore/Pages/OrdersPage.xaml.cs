﻿using AutoPartsStore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace AutoPartsStore.Pages
{
    public partial class OrdersPage : Page
    {
        private Frame _frame;
        private User _user;

        public ObservableCollection<OrderViewModel> Orders { get; set; }

        public OrdersPage(Frame frame, User user)
        {
            InitializeComponent();
            _frame = frame;
            _user = user;

            if (_user == null)
            {
                MessageBox.Show("Нужно войти в систему");
                _frame.Navigate(new LoginPage(_frame));
                return;
            }

            LoadOrders();
            DataContext = this;
        }

        private void LoadOrders()
        {
            using (var db = new StoreContext())
            {
                var ordersFromDb = db.Orders
                    .Where(o => o.UserId == _user.UserId)
                    .Include(o => o.Orderitems)
                        .ThenInclude(oi => oi.Product)
                    .OrderByDescending(o => o.OrderDate)
                    .ToList();

                Orders = new ObservableCollection<OrderViewModel>(
                    ordersFromDb.Select(o => new OrderViewModel(o))
                );
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new ProductsPage(_frame, _user));
        }
    }

    public class OrderViewModel
    {
        public int Id { get; set; }
        public DateTime CreatedAt { get; set; }
        public string StatusText { get; set; }
        public ObservableCollection<OrderItemViewModel> Items { get; set; }

        public decimal Total => Items.Sum(i => i.TotalPrice);

        public OrderViewModel(Order order)
        {
            Id = order.OrderId;
            CreatedAt = order.OrderDate;

            Items = new ObservableCollection<OrderItemViewModel>(
                order.Orderitems.Select(oi => new OrderItemViewModel(oi))
            );
        }
    }

    public class OrderItemViewModel
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }

        public decimal TotalPrice => Product.Price * Quantity;

        public OrderItemViewModel(Orderitem item)
        {
            Product = item.Product;
            Quantity = item.Quantity;
        }
    }
}