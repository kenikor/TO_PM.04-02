﻿using AutoPartsStore.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoPartsStore.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        private Frame _frame;
        private User _user;

        public ObservableCollection<Product> Products { get; set; }
        public ProductsPage(Frame frame, User user = null)
        {
            InitializeComponent();
            _frame = frame;
            _user = user;

            LoadProducts();
            this.DataContext = this;
        }

        private void LoadProducts()
        {
            try
            {
                using (var db = new StoreContext())
                {
                    // Загружаем список товаров из БД
                    Products = new ObservableCollection<Product>(db.Products.ToList());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
                Products = new ObservableCollection<Product>();
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Переход на главную
            _frame.Navigate(new HomePage(_frame, _user));
        }

        private void OpenCart_Click(object sender, RoutedEventArgs e)
        {
            if (_user == null)
            {
                MessageBox.Show("Нужно войти в систему, чтобы открыть корзину");
                return;
            }

            _frame.Navigate(new CartsPage(_frame, _user));
        }

        private void AddToCart_Click(object sender, RoutedEventArgs e)
        {
            // Получаем объект продукта напрямую из DataContext кнопки
            var button = sender as Button;
            var product = button?.DataContext as Product;

            if (product == null) return;

            if (_user == null)
            {
                MessageBox.Show("Пользователь не авторизован. Невозможно добавить в корзину.");
                return;
            }

            if (product.Stock <= 0)
            {
                MessageBox.Show($"Товара '{product.Name}' больше нет на складе!");
                return;
            }

            if (_user.Cart == null)
                _user.Cart = new ObservableCollection<CartItem>();

            var existingItem = _user.Cart.FirstOrDefault(ci => ci.Product.ProductId == product.ProductId);

            if (existingItem != null)
            {
                existingItem.Quantity += 1;
            }
            else
            {
                _user.Cart.Add(new CartItem
                {
                    Product = product,
                    Quantity = 1
                });
            }

            product.Stock -= 1;

            MessageBox.Show($"Товар '{product.Name}' добавлен в корзину.\nОсталось на складе: {product.Stock}");
        }
    }
}