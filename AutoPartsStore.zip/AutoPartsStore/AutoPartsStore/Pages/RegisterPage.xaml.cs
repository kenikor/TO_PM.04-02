﻿using AutoPartsStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoPartsStore.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        private Frame _frame;
        public RegisterPage(Frame frame)
        {
            InitializeComponent();
            _frame = frame;
        }
        private async void Register_Click(object sender, RoutedEventArgs e)
        {
            ErrorText.Text = "";

            string fullName = FullNameBox.Text;
            string email = EmailBox.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password))
            {
                ErrorText.Text = "Заполните все поля";
                return;
            }

            if (password != confirmPassword)
            {
                ErrorText.Text = "Пароли не совпадают";
                return;
            }

            if (password.Length < 6)
            {
                ErrorText.Text = "Минимум 6 символов";
                return;
            }

            try
            {
                await RegisterUser(fullName, email, password);

                MessageBox.Show("Регистрация успешна!");

                _frame.Navigate(new LoginPage(_frame)); // как navigate('/')
            }
            catch (Exception)
            {
                ErrorText.Text = "Ошибка регистрации";
            }
        }

        private async Task RegisterUser(string fullName, string email, string password)
        {
            await Task.Run(() =>
            {
                using (var db = new StoreContext())
                {
                    if (db.Users.Any(u => u.Email == email))
                        throw new Exception("User exists");

                    var user = new User
                    {
                        FullName = fullName,
                        Email = email,
                        PasswordHash = BCrypt.Net.BCrypt.HashPassword(password)
                    };

                    db.Users.Add(user);
                    db.SaveChanges();
                }
            });
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new HomePage(_frame));
        }

        private void GoToLogin_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new LoginPage(_frame));
        }
    }
}
